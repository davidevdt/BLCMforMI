	#include <Rcpp.h>
	#include <stdio.h>
	#include <iostream>
	#include <stdlib.h>
	#include <math.h>
	#include <time.h> 
	
	
	using namespace Rcpp;
	
	#define ZEROFLOAT 1.0E-300
	#define MAXNEG -1.0E300
	
	
	/*
			RANDOM VARIABLES
			
	*/
	
double ranf(void){
	double r;
	r = ((double) (rand()+1.0))/(RAND_MAX+2);
	return r;
	}
	double rand_(void){
		double r = 0;
		while(r==0||r==1){
			r=((double) rand())/RAND_MAX;
		}
		return r;
	}
	int multdev(int K_, NumericVector pr){
		int i = -1;
		double cp = 0, r;
		r = rand_();
		do{
			i++;
			cp+=pr(i);
		} while(r>cp && i<K_-1);
		return i;	//NB:ritorna un valore tra 0 e K-1
	}
	float expodev(void){
		static float q[8] = {
		0.6931472,0.9333737,0.9888778,0.9984959,0.9998293,0.9999833,0.9999986,1.0
		};
		static long i;
		static float sexpo,a,u,ustar,umin;
		static float *q1 = q;
		a = 0.0;
		u = ranf();
		goto S30;
		S20:
		a += *q1;
		S30:
		u += u;
		if(u <= 1.0) goto S20;
		u -= 1.0;
		if(u > *q1) goto S60;
		sexpo = a+u;
		return sexpo;
		S60:
		i = 1;
		ustar = ranf();
		umin = ustar;	
		S70:
		ustar = ranf();
		if(ustar < umin) umin = ustar;
		i += 1;
		if(u > *(q+i-1)) goto S70;
		sexpo = a+umin**q1;
		return sexpo;
	}
	double gamdev(double ia){
		double am, e, s, v1, v2, x, y,p,b;
		double zero = 1.0E-30;
		if(ia==0) return zero;
		else if(ia<1){
			b = 1.0+0.3678794*ia;
			S130:
			p = b*(ranf());
			if (p>=1.0) goto S140;
			x = exp(log(p)/ia);
			if (expodev()<x) goto S130;
			return x;
			S140:
			x = -log((b-p)/ia);
			if (expodev()<(1.0-ia)*log(x)) goto S130;
			return x;
		} 
		else if(ia==1){
			x = -log(ranf());
		} else {
			do{
				do{
					do{
						v1 = 2.0*ranf()-1.0;
						v2 = 2.0*ranf()-1.0;	
					} while(v1*v1+v2*v2>1.0);
					y= v2/(v1+zero);
					am = (ia-1);
					s = sqrt(2.0*am+1.0);
					x = s*y+am;
				} while(x<=0.0);
				if(fabs(am*log(x/am)-s*y)<1000)
					e = (1.0+y*y)*exp(am*log(x/am)-s*y);
				else 
					e = 0;
			} while (ranf()>e);
		}
		return x;	
	}
	
	void dirdev(int n, Rcpp::NumericVector a, Rcpp::NumericVector p){
	int i;
	double ptot=0.0;
	for(i=0;i<n;i++) {
		p(i)=gamdev(a(i));
		ptot+=p(i);
	}
	for(i=0;i<n;i++)
		p(i)/=ptot;
	}
	
	
	
	
	Rcpp::List countPatterns(Rcpp::IntegerMatrix R, Rcpp::IntegerMatrix Y,Rcpp::IntegerVector cpat,Rcpp::IntegerMatrix z,int nrec,int J){
		for(int i=0;i<nrec;i++){
			int j=0;
			int found=0;
			Rcpp::IntegerVector foundmiss(J);
			for(int s=0;s<J;s++){
				foundmiss(s)=0;
			}
			while(!found&&j<i){
				found=1;
				int k=0;
				
				while(found&&k<J){
					if(R(j,k)==1){
						if(R(i,k)==1){
							foundmiss(k)=1;
							k++;	
						}else{
							//foundmiss(k)=0;
							found=0;
							//k++;
						}
					}else{
						if(R(i,k)==1){
							//foundmiss(k)=0;
							found=0;
							//k++;		
						}else if(R(i,k)==0 && Y(j,k)!=Y(i,k)){
							found=0;
							//foundmiss(k)=0;
							//k++;
						}else{
							foundmiss(k)=1;
							k++;
						}
					}
				}
				if(!found){
					j++;
					
				}else{
					cpat(j)++;
					if(is_true(all(foundmiss==1))){
							z(i,0)=j;	//WARNING: z(,0) contains both common patterns of joint (Observed,Missing) OR fully jointly observed patterns
							//z(i,1)=1;
					}
				}
			}
			if(!found){
				cpat(i)++;
				z(i,0)=i;
			}
		}
		return Rcpp::List::create(cpat,z);					
	}
	
	
	
	
	double allocation_and_loglik(Rcpp::NumericVector pilat, Rcpp::List piresp, int nrec,Rcpp::NumericVector logpilat,Rcpp::List logpiresp,Rcpp::IntegerMatrix Y, int K, int J, Rcpp::IntegerVector ncat, Rcpp::IntegerVector npat,Rcpp::NumericVector a1, Rcpp::List a2, Rcpp::NumericVector nlat, Rcpp::List nresp, Rcpp::NumericVector hulplat,int b,Rcpp::IntegerVector sel,int type,Rcpp::IntegerMatrix z,Rcpp::IntegerMatrix R){
		int i,j,c,k,l;
		int lat;
		double llik = 0;
		double largest;
		double tot;	
		Rcpp::NumericVector rep1_ = Rcpp::clone(pilat);
		bool saveallocations = (is_true(any(sel==(b+1))) && b>0);
		for(i=0;i<K;i++){
	
			if(pilat(i)>ZEROFLOAT){
				logpilat(i)=(log(rep1_(i)));
			}else{
				logpilat(i)=log(ZEROFLOAT);
			}
		}
		for(j=0;j<J;j++){
			SEXP a_ = piresp[j];
			Rcpp::NumericVector presp(a_);
			SEXP b_ = logpiresp[j];
			Rcpp::NumericMatrix logpresp(b_);
			for(i=0;i<K;i++){
				for(c=0;c<ncat(j);c++){
					if(presp(c,i)>ZEROFLOAT){
						logpresp(c,i)=log(presp(c,i));
					}else{
						logpresp(c,i)=log(ZEROFLOAT);
					}
				}
			}
			logpiresp[j]=Rcpp::clone(logpresp);
		}
		
		
		for(i=0;i<K;i++){
				nlat(i)=0.0;
		}
		
		if(type<3){
		Rcpp::NumericVector rep3_ = Rcpp::clone(a1);
			for(j=0;j<J;j++){
				SEXP c_ =  nresp[j];
				Rcpp::NumericMatrix nres(c_);
				for(i=0;i<K;i++){
					for(c=0;c<ncat(j);c++){
						nres(c,i)=rep3_(j);
					}
				}
				nresp[j]=nres;
			}
		}else{
			for(j=0;j<J;j++){
				SEXP d_ = nresp[j];
				SEXP e_ = a2[j];
				Rcpp::NumericMatrix nres(d_);
				Rcpp::NumericVector prires = Rcpp::clone(e_);
				for(i=0;i<K;i++){
					for(c=0;c<ncat(j);c++){
						nres(c,i)=prires(c);
					}
				}
				nresp[j]=nres;
			}
		}
		
				
		
		
		for(k=0;k<nrec;k++){
		
			if(npat(k)>0){
				
				tot = 0.0;
				largest = MAXNEG;
				
				
				
				for(i=0;i<K;i++){
					hulplat(i) = logpilat(i);
					for(j=0;j<J;j++){
						
						if(R(k,j)==1){
							hulplat(i)+=0.0;
						}else{
							SEXP e_ = logpiresp[j];
							Rcpp::NumericMatrix logpresp(e_);
							hulplat(i)+=logpresp((Y(k,j)-1),i);
						}
					}
					if(hulplat(i)>largest){
						largest=hulplat(i);
					}
				}
				
				for(i=0;i<K;i++){
					hulplat(i)=(exp(hulplat(i)-largest));
					tot = tot+hulplat(i);
				
					
					  	
				}
				
				for(i=0;i<K;i++){
					hulplat(i)/=tot;
				}
				
				llik += npat(k)*(log(tot)+largest);
				
				
				if(saveallocations==FALSE){
					for(l=0;l<npat(k);l++){
						lat=multdev(K,hulplat);
						nlat(lat) += 1.0;
						for(j=0;j<J;j++){
							if(R(k,j)==0){
								SEXP f_ = nresp[j];
								Rcpp::NumericMatrix nres2(f_);
								nres2((Y(k,j)-1),lat) += 1.0;
								nresp[j] = Rcpp::clone(nres2);
							}					
						}
					}
				}else{
					for(int kk=0;kk<nrec;kk++){
						if(z(kk,0)==k){
							//lat = multdev(K,hulplat);
							//z(kk,1)= lat; 
							z(kk,1) = multdev(K,hulplat);
							nlat(z(kk,1)) += 1.0;
							for(j=0;j<J;j++){
								if(R(k,j)==0){
									SEXP f_ = nresp[j];
									Rcpp::NumericMatrix nres2(f_);
									nres2((Y(k,j)-1),z(kk,1)) += 1.0;
									nresp[j] = Rcpp::clone(nres2);
								}
							}
						}else{
							continue;
						}
					}
				}
				
				
				
					
			}
		}
		return llik;
				
	}
		
	
	double store(Rcpp::NumericVector mpilat, Rcpp::NumericVector pilat, Rcpp::List mpiresp,Rcpp::List piresp,Rcpp::NumericVector spilat,Rcpp::List spiresp,double loglik,int K,int J,Rcpp::IntegerVector ncat,double mloglik_){
	
		int i,j,c;
		Rcpp::NumericVector pilat_ = Rcpp::clone(pilat);
		for(i=0;i<K;i++){
			mpilat(i)+= pilat_(i);
			spilat(i) += (pilat_(i)*pilat_(i));
		}
		
		for(j=0;j<J;j++){
			SEXP a_ = piresp[j];
			SEXP b_ = mpiresp[j];
			SEXP c_ = spiresp[j];
			Rcpp::NumericMatrix presp = Rcpp::clone(a_);
			Rcpp::NumericMatrix mpresp(b_);
			Rcpp::NumericMatrix spresp(c_);
			for(i=0;i<K;i++){
				for(c=0;c<ncat(j);c++){
					mpresp(c,i)+=presp(c,i);
					spresp(c,i)+=(presp(c,i)*presp(c,i));
				}
			}
			mpiresp(j)=Rcpp::clone(mpresp);
			spiresp(j)=Rcpp::clone(spresp);
		}
		
		mloglik_ += loglik;
		return mloglik_;
	
	}
	
	
	double posterior_and_imputation(Rcpp::NumericVector nlat,Rcpp::NumericVector pilat, int nrec, Rcpp::List nresp,Rcpp::List piresp, Rcpp::IntegerVector ncat,int K,int J, int b,bool estimates,Rcpp::List imp,Rcpp::IntegerMatrix z,int nimp,int it3,Rcpp::NumericVector mpilat,Rcpp::List mpiresp,Rcpp::NumericVector spilat, Rcpp::List spiresp,double loglik,Rcpp::IntegerVector sel,Rcpp::IntegerMatrix R,double mloglik_,Rcpp::NumericVector V, double alpha,double c,double d){
		int i,j,s;
		double pro;
		double sumsup = 0.0;
		
		for(i = 0;i<(K-1);i++){
		
			sumsup += nlat(i);
			V(i) = as<double>(rbeta(1, 1 + nlat(i), alpha + (nrec-sumsup)));
		
		}
		pilat(0) = V[0];
		pro = 1.0;
		for(i=1;i<K;i++){
			pro *= (1.0-V(i-1));
			pilat(i) = V(i)*pro;
		}
		
		alpha = as<double>(rgamma(1,(c+K-1),1/(d-log(pilat(K-1)))));
		
		for(j=0;j<J;j++){
			SEXP a_ = nresp[j];
			SEXP b_ = piresp[j];
			Rcpp::NumericMatrix nres(a_);
			Rcpp::NumericMatrix pires(b_);
			for(i=0;i<K;i++){
				Rcpp::NumericVector pp(ncat(j));
				dirdev(ncat(j),nres(_,i),pp);
				pires(_,i)=Rcpp::clone(pp);
			}
			piresp[j]=pires;
		}
		
		if(is_true(any(sel==b)) && b>0){
			for(j=0;j<J;j++){
				if(is_true(any(R(_,j)==1))){	
					SEXP a_ = imp[j];
					SEXP b_ = piresp[j];
					Rcpp::IntegerMatrix IMP(a_);
					Rcpp::NumericMatrix pres(b_);
					int ind = 0;
					for(s=0;s<nrec;s++){
						for(i=0;i<K;i++){
							if (R(s,j)==1 && z(s,1)==i){
								IMP(ind,nimp)= (multdev(ncat(j),pres(_,i)))+1;
								ind+=1;
							}
						}
					}
					imp[j]=IMP;
				}
			}
		}
		
		if(estimates && (b>0 && b%it3==0)){
			mloglik_ = store(mpilat,pilat,mpiresp,piresp,spilat,spiresp,loglik,K,J,ncat,mloglik_);
		}
		return mloglik_;
		
	
	}
	// [[Rcpp::export]]
	
	
	Rcpp::List cppCycle2(IntegerMatrix Y,int K,int I,int it1,int it2, int it3, bool estimates, bool supit,int type, int n, int J, IntegerVector ncat, IntegerVector npattern, IntegerMatrix z,IntegerMatrix R, NumericVector pilat, NumericVector logpilat, NumericVector nlat,NumericVector hulplat, List piresp,List logpiresp,List nresp,NumericVector mpilat,NumericVector spilat,List mpiresp,List spiresp,double mloglik,double DIC,double f,List imp,int nimp,IntegerVector sel,double alpha,NumericVector a1,List a2, double loglik,bool infoclass,Rcpp::NumericVector V,double c,double d,bool count){
	
	
	
	int b;	
	double mloglik_;
	V[(K-1)] = 1;
	IntegerVector cK(K);
	int k;
	int cc;
	RNGScope scope;
	
	countPatterns(R,Y,npattern,z,n,J);
	
	loglik = allocation_and_loglik(pilat,piresp,n,logpilat,logpiresp,Y,K,J,ncat,npattern,a1,a2,nlat,nresp,hulplat,-1,sel,type,z,R);
	for(b=1;b<=it1;b++){
		posterior_and_imputation(nlat,pilat,n,nresp,piresp,ncat,K,J,-1,estimates,imp,z,nimp,it3,mpilat,mpiresp,spilat,spiresp,loglik,sel,R,mloglik_,V,alpha,c,d);
		loglik = allocation_and_loglik(pilat,piresp,n,logpilat,logpiresp,Y,K,J,ncat,npattern,a1,a2,nlat,nresp,hulplat,-1,sel,type,z,R);
		if(!supit && b%(it3*5)==0){
			Rcout << "Burn-in, iteration: " << (b) << " ,loglik = "  << (loglik) << std::endl;
		}
	}
	
	for(b=1;b<=it2;b++){
		mloglik_ = posterior_and_imputation(nlat,pilat,n,nresp,piresp,ncat,K,J,b,estimates,imp,z,nimp,it3,mpilat,mpiresp,spilat,spiresp,loglik,sel,R,mloglik_,V,alpha,c,d);
		loglik = allocation_and_loglik(pilat,piresp,n,logpilat,logpiresp,Y,K,J,ncat,npattern,a1,a2,nlat,nresp,hulplat,b,sel,type,z,R);
		if(!supit && b%(it3*5)==0){
			Rcout << "Posterior calculation, iteration: " << (b) << " ,loglik = "  << (loglik) << " 	,pi_1 " << (pilat(0)) << " 		,posterior hyperparameter pi_1 = "  << (nlat(0)) << std::endl;
		}
		
		if(count){
			cc = 0;
			for(k=0;k<K;k++){
				if(nlat(k)>0){
					cc+=1;
				}
			}
			cK(cc-1) +=1;
		
		}
		
		
		
		if(is_true(any(sel==b)) && b>0){
			nimp +=1;
		}
		if(is_true(any(sel==(b+1))) && b>0 && infoclass){
					for(int ss=0;ss<n;ss++){
					Rcout << (z(ss,1)) << "is the class of unit " << (ss) << " at imputation # " << (nimp+1) << std::endl; 
					}
				}
	}
	
	if(estimates){
				
				double loglikm;
				for(int i=0;i<K;i++){
					mpilat(i) *= f;
					if(mpilat(i)<1.0E-300){
						mpilat(i) = 1.0E-300;
					}
				}
				
				for(int i=0;i<K;i++){
					spilat(i) *= f;
					spilat(i)-=(mpilat(i)*mpilat(i));
					if(spilat(i)>0){
						spilat(i)=sqrt(spilat(i));
					}
				}
				
				
				for(int j=0;j<J;j++){
					SEXP tmp = mpiresp[j];
					Rcpp::NumericMatrix mpresp(tmp);
					for(int i=0;i<K;i++){
						for(int c=0;c<ncat(j);c++){
							mpresp(c,i) *= f;
							if(mpresp(c,i)<1.0E-300){
								mpresp(c,i) = 1.0E-300;
							}
						}
					}
					mpiresp[j]=mpresp;
				}
				
				
				for(int j=0;j<J;j++){
					SEXP tmp = mpiresp[j];
					SEXP tmp2 = spiresp[j];
					Rcpp::NumericMatrix mpresp(tmp);
					Rcpp::NumericMatrix spresp(tmp2);
					for(int i=0;i<K;i++){
						for(int c=0;c<ncat(j);c++){
							spresp(c,i) *= f;
							spresp(c,i)-=(mpresp(c,i)*mpresp(c,i));
							if(spresp(c,i)>0){
								spresp(c,i)=sqrt(spresp(c,i));
							}
						}
					}
					spiresp[j]=spresp;
				}
				mloglik = mloglik_*f;
				
				loglikm = allocation_and_loglik(mpilat,mpiresp,n,logpilat,logpiresp,Y,K,J,ncat,npattern,a1,a2,nlat,nresp,hulplat,-1,sel,type,z,R);
				DIC = -2*(2*mloglik-loglikm);	
	}
	
	
	return Rcpp::List::create(
							  Rcpp::Named("imp") = imp ,
							  Rcpp::Named("mpilat") = mpilat,
							  Rcpp::Named("mpiresp") = mpiresp,
							  Rcpp::Named("spilat") = spilat,
							  Rcpp::Named("spiresp") = spiresp,
							  Rcpp::Named("DIC") = DIC,
							Rcpp::Named("cK") = cK 	
							  );	
}

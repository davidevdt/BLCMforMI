dpmi <-
function(Y,K=3,alpha=1,prioresp=1,c=0.25,d=0.25,I=5,it1=500,it2=5000,it3=100,v=100,estimates=FALSE,probs=FALSE,supit=FALSE,type=1,plug=TRUE,infoclass=FALSE,rand=FALSE,count=TRUE){

if((prioresp<=0.00999) & estimates==TRUE){
warning("hyperparameter <<prioresp>> has been set very low (<.01). This might cause some NaN in the final estimates.",call.=FALSE,immediate.=TRUE)
}

ptm <- proc.time()
Y<-as.data.frame(Y)
n<-nrow(Y)
J<-ncol(Y)
Yd<-matrix(0,n,J)
colnames(Yd)<-colnames(Y)
cod=vector("list",J)
ncat<-rep(0,J)

for(j in 1:J){
ncat[j]<-length(table(Y[,j]))
cod[[j]]<-matrix(0,2,ncat[j])
cod[[j]][1,]<-names(table(Y[,j]))

Yd[,j]<-as.numeric(as.factor(Y[,j]))

cod[[j]][2,]<-names(table(Yd[,j]))
names(cod)[j]<-paste("item",j,sep="")
rownames(cod[[j]])<-c("original labels","new labels")
colnames(cod[[j]])<-rep("",ncat[j])
}


npattern = rep(0,n)
z = matrix(-1,n,2)#Nb: z salva le allocazioni (X_i) quando c'� da imputare
R<-ifelse(is.na(Yd),1,0)
logpilat = rep(0,K)
nlat = rep(0,K)
hulplat = rep(0,K)
piresp = vector("list", J)
logpiresp = vector("list", J)
nresp = vector("list", J)
V<-rep(0,K)
pilat<-rep(0,K)

if(rand==FALSE){
pilat = rep(1/K,K)
}else{
for(k in 1:K-1){
V[k]<-rbeta(1,1,alpha)
}
V[K]<-1
pilat[1]<-V[1]
for(k in 2:K){
pilat[k]<-V[k]*prod(1-V[1:k-1])
}
}


mpilat = rep(0,K)
spilat = rep(0,K)
mpiresp = vector("list",J)
spiresp = vector("list", J)
loglik = 0.0
mloglik = 0.0
DIC = 0.0
f = it3/it2

imp<-vector("list",J)
nimp<-0
sel<-floor(seq(floor(runif(1,1,v)),it2,length.out=I))

a1<-rep(prioresp,J)
a2<-vector("list",J)

if(type==1){
a1<-rep(prioresp,J)
} else if(type==2){
a1<-(prioresp)/(ncat)
}else if(type==3){
for(j in 1:J){
a2[[j]]<-((table(Yd[,j])/(n-sum(R[,j])))*(((prioresp)*ncat[j])/K))
}
}else if(type==4){
for(j in 1:J){
a2[[j]]<-((table(Yd[,j])/(n-sum(R[,j])))*((prioresp)/K))
}
}else{
stop("Type of prior not valid.")
}

for(j in 1:J){
if(probs==FALSE){
piresp[[j]]<-matrix(1/ncat[j],ncat[j],K)
}else{
piresp[[j]]<-matrix(0,ncat[j],K)
piresp[[j]]<-apply(piresp[[j]],2,function(x) table(Yd[,j])/(n-sum(R[,j])))
}
logpiresp[[j]] = matrix(0,ncat[j],K)
nresp[[j]] = matrix(0,ncat[j],K)
#P[[j]]<-matrix(a1[j],ncat[j],K)
#names(piresp)[j]<-paste("item",j,sep="")
names(imp)[j]<-noquote(paste("item",j,sep=""))

if(type<3){
a2[[j]]<-rep(0,2)
}

if(sum(R[,j])>0){
imp[[j]]<-matrix(NA,sum(R[,j]),I)
colnames(imp[[j]])<-1:I
rownames(imp[[j]])<-which(R[,j]==1)
}

if(estimates==TRUE){
names(mpiresp)[j]<-names(spiresp)[j]<-noquote(paste("item",j,sep=""))
mpiresp[[j]] = spiresp[[j]] = matrix(0,ncat[j],K)
colnames(mpiresp[[j]])<-colnames(spiresp[[j]])<-noquote(paste("Class",1:K,sep=" "))
rownames(mpiresp[[j]])<-rownames(spiresp[[j]])<-noquote(paste("Category",cod[[j]][1,],sep=" "))
}
}



mc<-cppCycle2(as.matrix(Yd),K,I,it1,it2,it3,estimates,supit,type,n,J,ncat,npattern,z,R,pilat,logpilat,nlat,hulplat,piresp,logpiresp,nresp,mpilat,spilat,mpiresp,spiresp,mloglik,DIC,f,imp,nimp,sel,alpha,a1,a2,loglik,infoclass,V,c,d,count)

cK<-mc$cK
cK<-cK/it2
imp<-mc$imp
if(estimates==TRUE){
mpilat<-round(mc$mpilat,4)
mpiresp<-lapply(mc$mpiresp,function(x) round(x,4))
spilat<-round(mc$spilat,4)
spiresp<-lapply(mc$spiresp, function(x) round(x,4))
DIC<-mc$DIC
names(mpilat)<-names(spilat)<-noquote(paste("Class",1:K,sep=" "))
names(DIC)<-"DIC"
}

imp2<-vector("list",J)
for(j in 1:J){
if(sum(R[,j]>0)){
imp2[[j]]<-matrix(0,sum(R[,j]),I)
for(i in 1:I){
for(m in 1:ncat[j]){
imp2[[j]][which(imp[[j]][,i]==cod[[j]][2,m]),i]<-as.numeric(noquote(cod[[j]][1,m]))
}
}
}
}
imp<-imp2
rm(imp2)

for(j in 1:J){
if(sum(R[,j])>0){
colnames(imp[[j]])<-1:I
rownames(imp[[j]])<-which(R[,j]==1)
}
}

if(plug==TRUE){

cmpletedata<-vector("list",I)

for(i in 1:I){

Y1<-as.matrix(Y)
for(j in 1:J){
if(sum(R[,j])>0){
Y1[as.numeric(row.names(imp[[j]])),j]<-as.numeric(imp[[j]][,i])
}
}
cmpletedata[[i]]<-Y1
names(cmpletedata)[i]<-noquote(paste("Imputed Dataset #",i,sep=" "))
cmpletedata[[i]]<-as.data.frame(cmpletedata[[i]])
colnames(cmpletedata[[i]])<-colnames(Y)
rownames(cmpletedata[[i]])<-1:n
}

}


ptmf<-proc.time()-ptm

if(estimates==TRUE & plug==TRUE){
list(imp=imp,datasets=cmpletedata,latentprob=mpilat,latentse=spilat,resprob=mpiresp,respse=spiresp,DIC=DIC,cK=cK,time=ptmf)
}else if(estimates==TRUE & plug==FALSE){
list(imp=imp,latentprob=mpilat,latentse=spilat,resprob=mpiresp,respse=spiresp,DIC=DIC,cK=cK,time=ptmf)
}else if(estimates==FALSE & plug==TRUE){
list(imp=imp,datasets=cmpletedata,cK=cK,time=ptmf)
}else{
list(imp=imp,cK=cK,time=ptmf)
}
}

multilevelLCMI <-
function(dat,GID=NULL,UID=NULL,var2=NULL,L,K,it1,it2,it3,it.print,v,I=5,pri2=1.0,pri1=1.0,priresp=1.0,priresp2=1.0,random=TRUE,num=TRUE,estimates=TRUE,count=FALSE,plot.loglik=FALSE,prec=4,restrict=FALSE,scale=1.0){

ptm <- proc.time()


if((pri2<=0.00999 | pri1<=0.00999 | priresp <=0.00999 | (priresp2<=0.00999 & !is.null(var2)) ) & estimates==TRUE){
warning("some hyperparameters have been set very low (<.01). This might cause some NaN in the final estimates.",call.=FALSE,immediate.=TRUE)
}

if(L<1|K<1){
stop("L or K are <1.",call.=FALSE)
}



if(it1==0){
stop("Set the number of iterations <<it1>>.",call.=FALSE)
}

doVar2<-TRUE
if(is.null(var2)){
doVar2<-FALSE
}


if(is.null(GID)){
if(L>1|doVar2){
stop("Grouping variable missing.",call.=FALSE)
}

}else{
GN<-colnames(dat)[GID]
}

sel<-floor(seq(floor(runif(1,1,v)),it2,length.out=I))


Y<-as.data.frame(dat)
n<-nrow(dat)
if(is.null(GID)){
GID<-1
Group<-rep(1,n)
dat<-as.data.frame(cbind(Group,dat))
Y<-as.data.frame(cbind(Group,Y))
colnames(Y)[GID]<-"Group"
J=1
}else{
dat<-cbind(dat[,GID],dat[,-GID])
GID<-1
Y<-as.data.frame(dat)
J<-length(table(Y[,GID]))
}

pllk<-rep(0,1)
if(plot.loglik){
pllk<-rep(0,(it1+it2))
}

TT2<-1
ncat2<-rep(0,1)
cod2<-0
ncat2<-0
nms2<-0
Y2<-matrix(0,1,1)
R2<-matrix(0,1,1)
YY2<-matrix(0,1,1)
nlat2<-vector("list",1)
piresp2<-vector("list",1)
f = it3/it2
piG<-rep(0,1)
nlatG<-rep(0,1)
wG<-rep(0,1)

GIDC<-Y[,GID]
GU<-as.numeric(as.factor(Y[,GID]))

if(doVar2){
Y2<-cbind(GU,Y[,var2])
Y2<-unique(Y2)
Y2<-Y2[order(Y2[,1]),]
Y2b<-Y2
R2<-ifelse(is.na(Y2[,-1]),1,0)
nms2<-names(Y[,var2])
TT2<-ncol(Y2[,-1])
ncat2<-rep(0,TT2)
cod2=vector("list",TT2)
piresp2<-vector("list",TT2)
nlat2<-vector("list",TT2)
for(tt in 1:TT2){
ncat2[tt]<-length(table(Y2[,(tt+1)]))
cod2[[tt]]<-matrix(0,2,ncat2[tt])
cod2[[tt]][1,]<-names(table(Y2[,tt+1]))
Y2[,tt+1]<-as.numeric(as.factor(Y2[,tt+1]))
cod2[[tt]][2,]<-names(table(Y2[,tt+1]))
nlat2[[tt]]<-matrix(0,L,ncat2[tt])
piresp2[[tt]]<-matrix(1/ncat2[tt],L,ncat2[tt])
if(random){
for(l in 1:L){
piresp2[[tt]][l,]<-rgamma(ncat2[[tt]],1,1)
piresp2[[tt]][l,]<-piresp2[[tt]][l,]/sum(piresp2[[tt]][l,])
}
}
}
YY2<-as.matrix(Y2[,-1])
}


if(J>1){
nj<-table(GU)
}else{
nj<-rep(0,1)
nj[1]<-n
}

if(doVar2==FALSE){
if(is.null(UID)){
YY<-Y[,-c(GID)]
colnames(YY)<-colnames(Y[,-c(GID)])
}else{
YY<-Y[,-c(GID,UID)]
colnames(YY)<-colnames(Y[,-c(GID,UID)])
}
}else{
if(is.null(UID)){
YY<-Y[,-c(GID,var2)]
colnames(YY)<-colnames(Y[,-c(GID,var2)])
}else{
YY<-Y[,-c(GID,UID,var2)]
colnames(YY)<-colnames(Y[,-c(GID,UID,var2)])
}

}
nms<-colnames(YY)

TT<-ncol(YY)
ncat<-rep(0,TT)
cod=vector("list",TT)
for(tt in 1:TT){
ncat[tt]<-length(table(YY[,tt]))
cod[[tt]]<-matrix(0,2,ncat[tt])
cod[[tt]][1,]<-names(table(YY[,tt]))
YY[,tt]<-as.numeric(as.factor(YY[,tt]))
cod[[tt]][2,]<-names(table(YY[,tt]))
}
Y<-cbind(GU,YY)


datJ<-vector("list",J)
R<-vector("list",J)
npattern<-vector("list",J)
npattern2<-rep(0,J)
pat2<-rep(-1,J)
pat<-vector("list",J)
w<-rep(-1,J)#allocazione del j-th gruppo 
z<-vector("list",J)#allocazione delle unita del j-th gruppo
nresp<-vector("list",TT)
piresp<-vector("list",TT)

pclasslev1<-vector("list",J)
jointlev2<-matrix(0.0,L,J)
grouploglik = rep(0.0,J)
loglik = 0.0
nlatw<-rep(0,L)
nlatk<-matrix(0,L,K)
piK<-matrix(1/K,L,K)
piW<-rep(1/L,L)
if(random==TRUE){
piW = rgamma(L,1,1)
piW = piW/sum(piW)
for(l in 1:L){
nlatk[l,]<-rep(0,K)
piK[l,] = rgamma(K,1,1)
piK[l,] = piK[l,]/(sum(piK[l,]))
}
if(restrict==FALSE){
for(tt in 1:TT){
piresp[[tt]]<-vector("list",L)
nresp[[tt]]<-vector("list",L)
for(l in 1:L){
nresp[[tt]][[l]]<-matrix(0,K,ncat[[tt]])
piresp[[tt]][[l]]<-matrix(0,K,ncat[tt])
for(k in 1:K){
piresp[[tt]][[l]][k,]<-rgamma(ncat[[tt]],1,1)
piresp[[tt]][[l]][k,]<-piresp[[tt]][[l]][k,]/sum(piresp[[tt]][[l]][k,])
}
}
}
}else{
for(tt in 1:TT){
piresp[[tt]]<-matrix(0,K,ncat[[tt]])
nresp[[tt]]<-matrix(0,K,ncat[[tt]])
for(k in 1:K){
piresp[[tt]][k,]<-rgamma(ncat[[tt]],1,1)
piresp[[tt]][k,]<-piresp[[tt]][k,]/sum(piresp[[tt]][k,])
}
}
}
}else{
if(restrict==FALSE){
for(tt in 1:TT){
piresp[[tt]]<-vector("list",L)
nresp[[tt]]<-vector("list",L)
for(l in 1:L){
piresp[[tt]][[l]]<-matrix(1/ncat[[tt]],K,ncat[[tt]])
nresp[[tt]][[l]]<-matrix(0,K,ncat[[tt]])
}
}
}else{
for(tt in 1:TT){
piresp[[tt]]<-matrix(1/ncat[[tt]],K,ncat[[tt]])
nresp[[tt]]<-matrix(0,K,ncat[[tt]])
}
}
}
imp<-vector("list",J)
nimp<-0
imp2<-vector("list",1)

if(doVar2){
imp2<-vector("list",TT2)
for(tt2 in 1:TT2){
if(sum(R2[,tt2]>0)){
if(I>0){
imp2[[tt2]]<-matrix(NA,sum(R2[,tt2]),I)
}
}
}
}

condp1<-matrix(0.0,L,J)

for(j in 1:J){
datJ[[j]]<-matrix(0,nj[j],TT)
R[[j]]<-matrix(0,nj[j],TT)
datJ[[j]]<-Y[GU==j,2:(TT+1)]
colnames(datJ[[j]])<-nms
R[[j]]<-ifelse(is.na(datJ[[j]]),1,0)
datJ[[j]]<-as.matrix(datJ[[j]])
R[[j]]<-as.matrix(R[[j]])
npattern[[j]]<-rep(0,nj[j])
pat[[j]]<-rep(-1,nj[j])
z[[j]]<-rep(-1,nj[j])
pclasslev1[[j]]<-vector("list",L)
for(l in 1:L){
pclasslev1[[j]][[l]]<-matrix(0,K,nj[j])
}
imp[[j]]<-vector("list",TT)
for(tt in 1:TT){
if(sum(R[[j]][,tt]>0)){
if(I>0){
imp[[j]][[tt]]<-matrix(NA,sum(R[[j]][,tt]),I)
colnames(imp[[j]][[tt]])<-1:I
rownames(imp[[j]][[tt]])<-which(R[[j]][,tt]==1)
}
}
}
}

RR<-ifelse(is.na(YY),1,0)
rm(YY)

piWm<-rep(0,L)
piWs<-rep(0,L)
piKm<-matrix(0,L,K)
piKs<-matrix(0,L,K)
pirespm<-vector("list",TT)
piresps<-vector("list",TT)
piresp2m<-vector("list",TT2)
piresp2s<-vector("list",TT2)


if(restrict==FALSE){
for(tt in 1:TT){
pirespm[[tt]]<-piresps[[tt]]<-vector("list",L)
for(l in 1:L){
pirespm[[tt]][[l]]<-matrix(0,K,ncat[tt])
piresps[[tt]][[l]]<-matrix(0,K,ncat[tt])
}
}
}else{
for(tt in 1:TT){
pirespm[[tt]]<-matrix(0,K,ncat[tt])
piresps[[tt]]<-matrix(0,K,ncat[tt])
}
}

if(doVar2){
for(tt in 1:TT2){
piresp2m[[tt]]<-matrix(0,L,ncat2[tt])
piresp2s[[tt]]<-matrix(0,L,ncat2[tt])
}
}


mc<-cppCycle(L,K,J,it1,it2,it3,it.print,pri2,pri1,priresp,priresp2,estimates,doVar2,sel,TT2,ncat2,YY2,R2,nlat2,piresp2,nj,TT,ncat,datJ,R,npattern,pat,w,z,nresp,piresp,pclasslev1,jointlev2,grouploglik,loglik,nlatw,nlatk,piK,piW,imp,imp2,nimp,count,piWm,piKm,pirespm,piresp2m,piWs,piKs,piresps,piresp2s,f,plot.loglik,pllk,restrict,condp1,npattern2,pat2,scale)


piWm<-mc$piWm
piKm<-mc$piKm
pirespm<-mc$pirespm
DIC<-mc$DIC
imp<-mc$imp
piWs<-mc$piWs
piKs<-mc$piKs
piresps<-mc$piresps
countIT<-mc$countIT


if(doVar2){
imp2<-mc$imp2
piresp2m<-mc$piresp2m
piresp2s<-mc$piresp2s
}else{
imp2<-NULL
piresp2m<-piresp2s<-NULL
}
if(!estimates){
DIC<-piWm<-piKm<-pirespm<-piWs<-piKs<-piresps<-piresp2m<-piresp2s<-NULL
}else{
names(piWm)<-names(piWs)<-noquote(paste("W=",1:L,sep=""))
rownames(piKm)<-rownames(piKs)<-noquote(paste("W=",1:L,sep=""))
colnames(piKm)<-colnames(piKs)<-noquote(paste("X=",1:K,sep=""))
piWm<-round(piWm,prec)
piKm<-round(piKm,prec)
piWs<-round(piWs,prec)
piKs<-round(piKs,prec)
for(tt in 1:TT){
names(pirespm)[tt]<-names(piresps)[tt]<-nms[tt]
if(restrict==FALSE){
for(l in 1:L){
names(pirespm[[tt]])[l]<-names(piresps[[tt]])[l]<-noquote(paste("W=",l,sep=""))
rownames(pirespm[[tt]][[l]])<-rownames(piresps[[tt]][[l]])<-noquote(paste("X=",1:K,sep=""))
colnames(pirespm[[tt]][[l]])<-colnames(piresps[[tt]][[l]])<-noquote(cod[[tt]][1,])
}
}else{
rownames(pirespm[[tt]])<-rownames(piresps[[tt]])<-noquote(paste("X=",1:K,sep=""))
colnames(pirespm[[tt]])<-colnames(piresps[[tt]])<-noquote(cod[[tt]][1,])
}
}
if(restrict==FALSE){
pirespm<-lapply(pirespm,function(x) lapply(x,function(y) round(y,prec)))
piresps<-lapply(piresps,function(x) lapply(x,function(y) round(y,prec)))
pirespm<-lapply(pirespm,function(x) lapply(x,function(y) t(y)))
piresps<-lapply(piresps,function(x) lapply(x,function(y) t(y)))
}else{
pirespm<-lapply(pirespm,function(x) round(x,prec))
piresps<-lapply(piresps,function(x) round(x,prec))
pirespm<-lapply(pirespm,function(x) t(x))
piresps<-lapply(piresps,function(x) t(x))
}
if(doVar2){
for(tt in 1:TT2){
names(piresp2m)[tt]<-names(piresp2s)[tt]<-nms2[tt]
rownames(piresp2m[[tt]])<-rownames(piresp2s[[tt]])<-noquote(paste("W=",1:L,sep=""))
colnames(piresp2m[[tt]])<-colnames(piresp2s[[tt]])<-noquote(cod2[[tt]][1,])
}
piresp2m<-lapply(piresp2m,function(x) round(x,prec))
piresp2s<-lapply(piresp2s,function(x) round(x,prec))
piresp2m<-lapply(piresp2m,function(y) t(y))
piresp2s<-lapply(piresp2s,function(y) t(y))
}
}

if(doVar2){
if(it2>0 & I>0){
imp2_<-vector("list",TT2)
for(tt2 in 1:TT2){
if(sum(R2[,tt2])>0){
imp2_[[tt2]]<-matrix(NA,sum(R2[,tt2]),I)
for(i in 1:I){
for(m2 in 1:ncat2[tt2]){
if(num){
imp2_[[tt2]][which(imp2[[tt2]][,i]==cod2[[tt2]][2,m2]),i]<-as.numeric(noquote(cod2[[tt2]][1,m2]))
}else{
imp2_[[tt2]][which(imp2[[tt2]][,i]==cod2[[tt2]][2,m2]),i]<-as.factor(noquote(cod2[[tt2]][1,m2]))
}
}
}
}
}

imp2<-imp2_
rm(imp2_)
names(imp2)<-nms2
for(tt2 in 1:TT2){
if(sum(R2[,tt2]>0)){
if(I>0){
colnames(imp2[[tt2]])<-1:I
rownames(imp2[[tt2]])<-which(R2[,tt2]==1)
}
}
}

imp22<-vector("list",J)
for(j in 1:J){
imp22[[j]]<-vector("list",TT)
for(tt in 1:TT){
if(sum(R[[j]][,tt])>0){
imp22[[j]][[tt]]<-matrix(NA,sum(R[[j]][,tt]),I)
for(i in 1:I){
for(m in 1:ncat[tt]){
if(num){
imp22[[j]][[tt]][which(imp[[j]][[tt]][,i]==cod[[tt]][2,m]),i]<-as.numeric(noquote(cod[[tt]][1,m]))
}else{
imp22[[j]][[tt]][which(imp[[j]][[tt]][,i]==cod[[tt]][2,m]),i]<-as.factor(noquote(cod[[tt]][1,m]))
}
}
}
}
}
}
imp<-imp22
rm(imp22)
cmpletedata<-vector("list",I)

for(j in 1:J){
names(imp)[j]<-noquote(paste("Group",j,sep=" "))
for(tt in 1:TT){
names(imp[[j]])[tt]<-nms[tt]
if(sum(R[[j]][,tt])>0){
colnames(imp[[j]][[tt]])<-1:I
rownames(imp[[j]][[tt]])<-which(R[[j]][,tt]==1)
}
}
}


for(i in 1:I){
YR2<-as.matrix(Y2b[,-1])
for(t2 in 1:TT2){
if(sum(R2[,t2])>0){
YR2[as.numeric(row.names(imp2[[t2]])),t2]=imp2[[t2]][,i]
}
}
YR<-vector("list",J)
for(j in 1:J){
YR[[j]]<-as.matrix(Y[GU==j,-1])
for(tt in 1:TT){
for(m in 1:ncat[tt]){
if(num){
YR[[j]][which(Y[GU==j,tt+1]==cod[[tt]][2,m]),tt]<-as.numeric(noquote(cod[[tt]][1,m]))
}else{
YR[[j]][which(Y[GU==j,tt+1]==cod[[tt]][2,m]),tt]<-as.factor(noquote(cod[[tt]][1,m]))
}
}
if(sum(R[[j]][,tt])>0){
YR[[j]][as.numeric(row.names(imp[[j]][[tt]])),tt]<-imp[[j]][[tt]][,i]
}
}

if(J>1){
YR[[j]]<-data.frame(rep(j,nj[j]),YR[[j]])
cmpletedata[[i]]<-rbind(cmpletedata[[i]],YR[[j]])
cmpletedata[[i]][cmpletedata[[i]][,1]==j,1]=GIDC[which(GU==j)]
}else{
cmpletedata[[i]]<-YR[[j]]
}
}

cmpletedata[[i]]<-as.data.frame(cmpletedata[[i]])

YR2 = as.data.frame(YR2)
cmpletedata[[i]]<-data.frame(cmpletedata[[i]],matrix(NA,nrow(cmpletedata[[i]]),TT2))
for(t2 in 1:TT2){
for(j in 1:J){
cmpletedata[[i]][which(cmpletedata[[i]][,1]==GIDC[which(GU==j)][1]),t2+(TT+1)]=YR2[j,t2]
}
}
cmpletedata[[i]]<-as.data.frame(cmpletedata[[i]])
colnames(cmpletedata[[i]])<-c(GN,nms,nms2)
rownames(cmpletedata[[i]])<-1:n
names(cmpletedata)[i]<-noquote(paste("Imputed Dataset #",i,sep=" "))
}
}
}else{
if(it2>0 && I>0){
imp22<-vector("list",J)
for(j in 1:J){
imp22[[j]]<-vector("list",TT)
for(tt in 1:TT){
if(sum(R[[j]][,tt])>0){
imp22[[j]][[tt]]<-matrix(NA,sum(R[[j]][,tt]),I)
for(i in 1:I){
for(m in 1:ncat[tt]){
if(num){
imp22[[j]][[tt]][which(imp[[j]][[tt]][,i]==cod[[tt]][2,m]),i]<-as.numeric(noquote(cod[[tt]][1,m]))
}else{
imp22[[j]][[tt]][which(imp[[j]][[tt]][,i]==cod[[tt]][2,m]),i]<-as.factor(noquote(cod[[tt]][1,m]))
}
}
}
}
}
}
imp<-imp22
rm(imp22)
for(j in 1:J){
names(imp)[j]<-noquote(paste("Group",j,sep=" "))
for(tt in 1:TT){
names(imp[[j]])[tt]<-nms[tt]
if(sum(R[[j]][,tt])>0){
colnames(imp[[j]][[tt]])<-1:I
rownames(imp[[j]][[tt]])<-which(R[[j]][,tt]==1)
}
}
}
cmpletedata<-vector("list",I)
for(i in 1:I){
YR<-vector("list",J)
for(j in 1:J){
YR[[j]]<-as.matrix(Y[GU==j,-1])
for(tt in 1:TT){
for(m in 1:ncat[tt]){
if(num){
YR[[j]][which(Y[GU==j,tt+1]==cod[[tt]][2,m]),tt]<-as.numeric(noquote(cod[[tt]][1,m]))
}else{
YR[[j]][which(Y[GU==j,tt+1]==cod[[tt]][2,m]),tt]<-as.factor(noquote(cod[[tt]][1,m]))
}
}
if(sum(R[[j]][,tt])>0){
YR[[j]][as.numeric(row.names(imp[[j]][[tt]])),tt]<-imp[[j]][[tt]][,i]
}
}
if(J>1){
YR[[j]]<-cbind(rep(j,nj[j]),YR[[j]])
cmpletedata[[i]]<-rbind(cmpletedata[[i]],YR[[j]])
cmpletedata[[i]][cmpletedata[[i]][,1]==j,1]=GIDC[which(GU==j)]
}else{
cmpletedata[[i]]<-YR[[j]]
}
}
cmpletedata[[i]]<-as.data.frame(cmpletedata[[i]])

if(J>1){
colnames(cmpletedata[[i]])<-c(GN,nms)
rownames(cmpletedata[[i]])<-1:n
names(cmpletedata)[i]<-noquote(paste("Imputed Dataset #",i,sep=" "))
}else{
colnames(cmpletedata[[i]])<-nms
rownames(cmpletedata[[i]])<-1:n
names(cmpletedata)[i]<-noquote(paste("Imputed Dataset #",i,sep=" "))
}
}
}
}

if(it2==0||I==0){
imp = NULL
imp2 = NULL
cmpletedata = NULL
}

if(plot.loglik & !count){
maxlik = mc$maxlik
pllk = mc$pllk
pllk = maxlik-pllk
#plot(pllk,type="l",lwd=2,xlab="t",ylab="(max(ll)-ll)",main="log-likelihood ratios",xaxt="n")
#axis(side=1,at=1:length(pllk),labels=1:length(pllk))
plot(pllk,type="l",lwd=2,xlab="t",ylab="ll(max)-ll",main="log-likelihood ratios",ylim=c(-.1,min(500,max(pllk))))
countK = NULL
countL = NULL
}else if(!plot.loglik & count){
countK<-mc$countK
countIT[countIT==0]<-1
countK<-countK/countIT
countL<-mc$countL
countL<-countL/it2
names(countL)<-paste("L=",1:L,sep="")
rownames(countK)<-paste("W=",1:L,sep="")
colnames(countK)<-paste("K=",1:K,sep="")
if(L>1){
par(mfrow=c(2,1))
plot(countL,type="h",lwd="3",col=ifelse(countL==max(countL),"red","black"),xlab="Level 2 Class",ylab="Freq.",main= "Distribution of L",xaxt="n")
axis(side=1,at=1:L,labels=paste("L=",1:L,sep=""))
cols<-sample(1:657,L,rep=F)
matplot(t(countK),type="s",lwd=3,ylim=c(0,1.5),lty=1,xlab="Level 1 Class",ylab="Freq.",main="Distribution of K|W",yaxt="n",col=colors()[cols],xaxt="n")
if(L>2){
legend(1,1.5,legend=paste("W = ",1:L,sep=""),fill=colors()[cols],ncol=floor(L/3))
}else{
legend(1,1.5,legend=paste("W = ",1:L,sep=""),fill=colors()[cols])
}
axis(side=1,at=1:K,labels=paste("K = ",1:K,sep=""))
axis(side=2,at=seq(0,1,by=0.1),labels=seq(0,1,by=0.1))
par(mfrow=c(1,1))
}else{
plot(1:K,countK,type="h",lwd="3",col=ifelse(countK==max(countK),"red","black"),xlab="Level 1 Class",ylab="Freq.",main= "Distribution of K",xaxt="n",ylim=c(0,1))
axis(side=1,at=1:K,labels=paste("K=",1:K,sep=""))
}
}else if(plot.loglik & count){
maxlik = mc$maxlik
pllk = mc$pllk
pllk = maxlik-pllk
countK<-mc$countK
countIT[countIT==0]<-1
countK<-countK/countIT
rownames(countK)<-paste("W=",1:L,sep="")
colnames(countK)<-paste("K=",1:K,sep="")
countL<-mc$countL
countL<-countL/it2
names(countL)<-paste("L=",1:L,sep="")
if(L>1){
par(mfrow=c(3,1))
plot(pllk,type="l",lwd=2,xlab="t",ylab="ll(max)-ll",main="log-likelihood ratios",ylim=c(-.1,min(500,max(pllk))))
plot(countL,type="h",lwd="3",col=ifelse(countL==max(countL),"red","black"),xlab="Level 2 Class",ylab="Freq.",main= "Distribution of L",xaxt="n")
axis(side=1,at=1:L,labels=paste("L=",1:L,sep=""))
cols<-sample(1:657,L,rep=F)
matplot(t(countK),type="s",lwd=3,ylim=c(0,1.5),lty=1,xlab="Level 1 Class",ylab="Freq.",main="Distribution of K|W",yaxt="n",col=colors()[cols],xaxt="n")
if(L>2){
legend(1,1.5,legend=paste("W = ",1:L,sep=""),fill=colors()[cols],ncol=floor(L/3))
}else{
legend(1,1.5,legend=paste("W = ",1:L,sep=""),fill=colors()[cols])
}
axis(side=1,at=1:K,labels=paste("K = ",1:K,sep=""))
axis(side=2,at=seq(0,1,by=0.1),labels=seq(0,1,by=0.1))
par(mfrow=c(1,1))
}else{
par(mfrow=c(2,1))
plot(pllk,type="l",lwd=2,xlab="t",ylab="ll(max)-ll",main="log-likelihood ratios",ylim=c(-.1,min(500,max(pllk))))
plot(1:K,countK,type="h",lwd="3",col=ifelse(countK==max(countK),"red","black"),xlab="Level 1 Class",ylab="Freq.",main= "Distribution of K",xaxt="n",ylim=c(0,1))
axis(side=1,at=1:K,labels=paste("K=",1:K,sep=""))
par(mfrow=c(1,1))
}
}else{
countK = NULL
countL = NULL
countG = NULL
}

ptmf<-proc.time()-ptm

  return(list(implev1=imp,implev2=imp2,datasets=cmpletedata,piL=piWm,piLses=piWs,piK=piKm,piKses=piKs,picondlev1=pirespm,picondlev1ses=piresps,picondlev2=piresp2m,picondlev2ses=piresp2s,DIC=DIC,freqL=countL,freqK=countK,time=ptmf))


}
